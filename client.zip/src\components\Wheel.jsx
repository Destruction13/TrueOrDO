import { useEffect, useMemo, useRef, useState } from "react";

const SEGMENT_COLORS = [
  "rgba(46, 230, 255, 0.32)",
  "rgba(255, 122, 217, 0.3)",
  "rgba(124, 255, 107, 0.3)",
  "rgba(86, 150, 255, 0.3)",
  "rgba(255, 196, 46, 0.26)",
  "rgba(255, 107, 107, 0.28)"
];
const VIEWPORT_SCALE = 0.6;
const MIN_WHEEL_SIZE = 240;
const MAX_LABEL_WORDS = 2;
const MAX_LABEL_CHARS = 18;
const SPIN_MIN_DURATION = 5400;
const SPIN_MAX_DURATION = 7600;
const SPIN_MIN_TURNS = 5;
const SPIN_MAX_TURNS = 7;
const SPIN_REVEAL_MIN_DELAY = 160;
const SPIN_REVEAL_MAX_DELAY = 280;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function lerp(min, max, t) {
  return min + (max - min) * t;
}

function createSeededRng(seed) {
  let value = seed % 2147483647;
  if (value <= 0) {
    value += 2147483646;
  }
  return () => {
    value = (value * 16807) % 2147483647;
    return value / 2147483647;
  };
}

function easeInQuad(t) {
  return t * t;
}

function easeOutCubic(t) {
  return 1 - Math.pow(1 - t, 3);
}

function easeOutQuint(t) {
  return 1 - Math.pow(1 - t, 5);
}

function smoothstep(t) {
  return t * t * (3 - 2 * t);
}

function makeShortLabel(text) {
  const normalized = String(text ?? "").trim();
  if (!normalized) {
    return "";
  }
  const words = normalized.split(/\s+/).slice(0, MAX_LABEL_WORDS);
  let short = words.join(" ");
  if (short.length > MAX_LABEL_CHARS) {
    short = `${short.slice(0, Math.max(MAX_LABEL_CHARS - 3, 1))}...`;
  }
  return short;
}

function truncateText(ctx, text, maxWidth) {
  if (!text) {
    return "";
  }
  if (ctx.measureText(text).width <= maxWidth) {
    return text;
  }
  let trimmed = text;
  while (trimmed.length > 0 && ctx.measureText(`${trimmed}...`).width > maxWidth) {
    trimmed = trimmed.slice(0, -1);
  }
  return trimmed ? `${trimmed}...` : "";
}

function measureMaxTextWidth(ctx, items) {
  let max = 0;
  for (const item of items) {
    const text = String(item ?? "");
    if (!text) {
      continue;
    }
    const width = ctx.measureText(text).width;
    if (width > max) {
      max = width;
    }
  }
  return max;
}

function getWheelSize(container) {
  const viewportMin = Math.min(window.innerWidth || 0, window.innerHeight || 0);
  const target = viewportMin * VIEWPORT_SCALE;
  const containerWidth = Math.max((container?.clientWidth || 0) - 16, 0);
  const maxSize = Math.min(target, containerWidth || target);
  if (!maxSize) {
    return 0;
  }
  const minSize = Math.min(MIN_WHEEL_SIZE, maxSize);
  return clamp(target, minSize, maxSize);
}

function getLayout(size, total) {
  const center = size / 2;
  const radius = center - Math.max(2, size * 0.01);
  const arc = (Math.PI * 2) / total;
  const innerRadius = radius * 0.34;
  const radialSpace = radius - innerRadius;
  const textRadius = innerRadius + radialSpace * 0.5;
  const availableRadial = radialSpace * 0.9;
  const chord = 2 * textRadius * Math.sin(arc / 2);
  const availableChord = total <= 1 ? radialSpace : chord;
  return {
    center,
    radius,
    arc,
    radialSpace,
    textRadius,
    availableRadial,
    availableChord
  };
}

function getFontSize(size, layout) {
  const chordSpan = 2 * layout.textRadius * Math.sin(layout.arc / 2);
  return Math.max(
    12,
    Math.min(
      22,
      Math.floor(Math.min(size * 0.065, chordSpan * 0.6, layout.radialSpace * 0.7))
    )
  );
}

function computeLayout(ctx, labels, size) {
  const total = Math.max(labels.length, 1);
  const layout = getLayout(size, total);
  const available = Math.min(layout.availableRadial, layout.availableChord) * 0.92;
  let fontSize = getFontSize(size, layout);
  let iterations = 0;
  ctx.font = `600 ${fontSize}px "Space Grotesk", "Segoe UI", sans-serif`;
  let maxWidth = measureMaxTextWidth(ctx, labels);
  while (maxWidth > available && fontSize > 10 && iterations < 8) {
    fontSize -= 1;
    ctx.font = `600 ${fontSize}px "Space Grotesk", "Segoe UI", sans-serif`;
    maxWidth = measureMaxTextWidth(ctx, labels);
    iterations += 1;
  }
  const displayLabels = labels.map((label) => truncateText(ctx, label, available));
  return {
    ...layout,
    size,
    fontSize,
    textMaxWidth: available,
    displayLabels
  };
}

function drawWheel(ctx, layout, labels, selectedIndex) {
  const total = Math.max(labels.length, 1);
  const center = layout.center;
  const radius = layout.radius;
  const arc = layout.arc;
  const startAngle = -Math.PI / 2;

  ctx.clearRect(0, 0, layout.size, layout.size);

  for (let i = 0; i < total; i += 1) {
    const from = startAngle + i * arc;
    const to = from + arc;
    const isSelected = selectedIndex === i;
    const color = SEGMENT_COLORS[i % SEGMENT_COLORS.length];
    ctx.beginPath();
    ctx.moveTo(center, center);
    ctx.arc(center, center, radius, from, to, false);
    ctx.closePath();
    ctx.fillStyle = isSelected ? "rgba(255, 122, 217, 0.38)" : color;
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = Math.max(1, layout.size * 0.004);
    ctx.stroke();
  }

  if (selectedIndex != null && selectedIndex >= 0 && selectedIndex < total) {
    const from = startAngle + selectedIndex * arc;
    const to = from + arc;
    ctx.beginPath();
    ctx.arc(center, center, radius - layout.size * 0.008, from, to, false);
    ctx.strokeStyle = "rgba(255, 122, 217, 0.8)";
    ctx.lineWidth = Math.max(2, layout.size * 0.012);
    ctx.stroke();
  }

  if (!labels.length) {
    return;
  }

  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = `600 ${layout.fontSize}px "Space Grotesk", "Segoe UI", sans-serif`;

  for (let i = 0; i < labels.length; i += 1) {
    const label = labels[i];
    if (!label) {
      continue;
    }
    const angle = startAngle + i * arc + arc / 2;
    ctx.save();
    ctx.translate(center, center);
    ctx.rotate(angle);
    ctx.fillStyle =
      selectedIndex === i ? "rgba(255, 122, 217, 0.95)" : "rgba(234, 242, 255, 0.9)";
    ctx.fillText(label, layout.textRadius, 0);
    ctx.restore();
  }
}

function Wheel({
  title,
  items,
  spinIndex,
  spinTick,
  spinning,
  selectedIndex,
  resultLabel,
  resultText,
  onReveal
}) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [isRevealed, setIsRevealed] = useState(false);
  const [wheelSize, setWheelSize] = useState(0);
  const sizeRef = useRef(0);
  const layoutRef = useRef(null);
  const labelsRef = useRef([]);
  const rotationRef = useRef(0);
  const animRef = useRef(null);
  const revealTimeoutRef = useRef(null);
  const pointerKickTimeoutRef = useRef(null);
  const lastDetentRef = useRef(0);
  const lastTickAtRef = useRef(0);
  const bodyRef = useRef(null);
  const canvasRef = useRef(null);
  const pointerRef = useRef(null);
  const onRevealRef = useRef(onReveal);

  const safeSelectedIndex =
    selectedIndex != null && selectedIndex >= 0 && selectedIndex < items.length
      ? selectedIndex
      : null;
  const safeSpinIndex =
    spinIndex != null && spinIndex >= 0 && spinIndex < items.length ? spinIndex : null;
  const highlightIndex =
    isRevealed && (safeSelectedIndex != null || safeSpinIndex != null)
      ? safeSelectedIndex ?? safeSpinIndex
      : null;
  const shortLabels = useMemo(() => items.map(makeShortLabel), [items]);

  useEffect(() => {
    return () => {
      if (animRef.current) {
        cancelAnimationFrame(animRef.current);
      }
      if (revealTimeoutRef.current) {
        clearTimeout(revealTimeoutRef.current);
      }
      if (pointerKickTimeoutRef.current) {
        clearTimeout(pointerKickTimeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    onRevealRef.current = onReveal;
  }, [onReveal]);

  useEffect(() => {
    if (safeSpinIndex == null || !items.length) {
      return;
    }
    const canvas = canvasRef.current;
    if (!canvas) {
      return;
    }

    if (animRef.current) {
      cancelAnimationFrame(animRef.current);
    }
    if (revealTimeoutRef.current) {
      clearTimeout(revealTimeoutRef.current);
      revealTimeoutRef.current = null;
    }
    if (pointerKickTimeoutRef.current) {
      clearTimeout(pointerKickTimeoutRef.current);
      pointerKickTimeoutRef.current = null;
    }

    setIsRevealed(false);
    setIsAnimating(true);
    lastTickAtRef.current = 0;

    const segment = 360 / items.length;
    const seed =
      (spinTick + 1) * 131 + (safeSpinIndex + 1) * 17 + items.length * 29;
    const rng = createSeededRng(seed);
    const extraTurns = Math.floor(lerp(SPIN_MIN_TURNS, SPIN_MAX_TURNS + 1, rng()));
    const offset = 360 - safeSpinIndex * segment - segment / 2;
    const normalized = ((rotationRef.current % 360) + 360) % 360;
    const target = rotationRef.current + 360 * extraTurns + offset - normalized;
    const start = rotationRef.current;
    const totalAngle = target - start;

    const duration = Math.round(lerp(SPIN_MIN_DURATION, SPIN_MAX_DURATION, rng()));
    let accelMs = lerp(350, 650, rng());
    let plateauMs = lerp(900, 1400, rng());
    let finalMs = lerp(900, 1400, rng());
    let decelMs = duration - accelMs - plateauMs - finalMs;
    if (decelMs < 2400) {
      const shortfall = 2400 - decelMs;
      const plateauRoom = Math.max(plateauMs - 650, 0);
      const reducePlateau = Math.min(plateauRoom, shortfall * 0.6);
      plateauMs -= reducePlateau;
      const remaining = shortfall - reducePlateau;
      finalMs = Math.max(700, finalMs - remaining);
      decelMs = duration - accelMs - plateauMs - finalMs;
    }

    const tA = accelMs / duration;
    const tB = (accelMs + plateauMs) / duration;
    const tC = (accelMs + plateauMs + decelMs) / duration;

    let distA = lerp(0.08, 0.12, rng());
    let distB = lerp(0.26, 0.34, rng());
    let distD = lerp(0.12, 0.18, rng());
    let distC = 1 - distA - distB - distD;
    if (distC < 0.32) {
      const deficit = 0.32 - distC;
      const adjust = Math.min(deficit, Math.max(distB - 0.18, 0));
      distB -= adjust;
      distC = 1 - distA - distB - distD;
    }

    const detentBase = Math.min(segment * 0.22, 7);
    const detentJitter = lerp(0.9, 1.12, rng());
    const wobbleAmplitude = segment * lerp(0.01, 0.04, rng());
    const wobbleFrequency = lerp(1.6, 2.6, rng());
    const wobblePhase = rng() * Math.PI * 2;
    const revealDelay = Math.round(
      lerp(SPIN_REVEAL_MIN_DELAY, SPIN_REVEAL_MAX_DELAY, rng())
    );

    lastDetentRef.current = Math.floor(start / segment);

    if (pointerRef.current) {
      pointerRef.current.style.setProperty("--pointer-kick", "0deg");
      pointerRef.current.style.setProperty("--pointer-lift", "0px");
    }

    const startTime = performance.now();

    const progressAt = (t) => {
      if (t <= tA) {
        const local = tA > 0 ? t / tA : 1;
        return easeInQuad(local) * distA;
      }
      if (t <= tB) {
        const local = (t - tA) / Math.max(tB - tA, 0.0001);
        return distA + local * distB;
      }
      if (t <= tC) {
        const local = (t - tB) / Math.max(tC - tB, 0.0001);
        return distA + distB + easeOutCubic(local) * distC;
      }
      const local = (t - tC) / Math.max(1 - tC, 0.0001);
      return distA + distB + distC + easeOutQuint(local) * distD;
    };

    const triggerPointerTick = (strength, now) => {
      const pointer = pointerRef.current;
      if (!pointer) {
        return;
      }
      if (now - lastTickAtRef.current < 32) {
        return;
      }
      lastTickAtRef.current = now;
      if (pointerKickTimeoutRef.current) {
        clearTimeout(pointerKickTimeoutRef.current);
      }
      const kick = -(3 + 8 * strength);
      const lift = -(1 + 4 * strength);
      pointer.style.setProperty("--pointer-kick", `${kick}deg`);
      pointer.style.setProperty("--pointer-lift", `${lift}px`);
      pointerKickTimeoutRef.current = window.setTimeout(() => {
        if (!pointerRef.current) {
          return;
        }
        pointerRef.current.style.setProperty("--pointer-kick", "0deg");
        pointerRef.current.style.setProperty("--pointer-lift", "0px");
      }, 110);
    };

    const tick = (now) => {
      const raw = (now - startTime) / duration;
      const t = clamp(raw, 0, 1);
      const progress = Math.min(1, Math.max(0, progressAt(t)));
      const baseAngle = start + totalAngle * progress;

      if (t >= 1) {
        rotationRef.current = target;
        canvas.style.setProperty("--rotation", `${target}deg`);
        if (revealTimeoutRef.current) {
          clearTimeout(revealTimeoutRef.current);
        }
        revealTimeoutRef.current = window.setTimeout(() => {
          setIsAnimating(false);
          setIsRevealed(true);
          if (typeof onRevealRef.current === "function") {
            onRevealRef.current();
          }
        }, revealDelay);
        return;
      }

      const lockStart = 0.985;
      const lockProgress = smoothstep(clamp((t - lockStart) / (1 - lockStart), 0, 1));
      const settle = 1 - lockProgress;
      const wobbleScale = t > tB ? (1 - t) * settle : 0;
      const wobble =
        Math.sin((t * wobbleFrequency + wobblePhase) * Math.PI * 2) *
        wobbleAmplitude *
        wobbleScale;
      const angleWithWobble = baseAngle - wobble;

      const phaseRaw = (baseAngle / segment) % 1;
      const phase = phaseRaw < 0 ? phaseRaw + 1 : phaseRaw;
      const tickProgress = tB < 1 ? smoothstep(clamp((t - tB) / (1 - tB), 0, 1)) : 1;
      const tickStrength = 0.2 + 0.8 * tickProgress;
      const slow = 1 - Math.sin(Math.PI * phase);
      const detent = detentBase * detentJitter * tickStrength * slow * settle;
      const rawAngle = angleWithWobble - detent;
      const displayAngle = lerp(rawAngle, target, lockProgress);
      rotationRef.current = displayAngle;
      canvas.style.setProperty("--rotation", `${displayAngle}deg`);

      const detentIndex = Math.floor(baseAngle / segment);
      if (detentIndex > lastDetentRef.current) {
        lastDetentRef.current = detentIndex;
        triggerPointerTick(tickStrength, now);
      }

      animRef.current = requestAnimationFrame(tick);
    };

    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) {
        cancelAnimationFrame(animRef.current);
        animRef.current = null;
      }
      if (revealTimeoutRef.current) {
        clearTimeout(revealTimeoutRef.current);
        revealTimeoutRef.current = null;
      }
      if (pointerKickTimeoutRef.current) {
        clearTimeout(pointerKickTimeoutRef.current);
        pointerKickTimeoutRef.current = null;
      }
    };
  }, [safeSpinIndex, spinTick, items.length]);

  useEffect(() => {
    const body = bodyRef.current;
    if (!body) {
      return;
    }
    const container = body.closest(".wheel-stage") || body.parentElement || body;
    let frame = null;

    const updateSize = () => {
      const nextSize = getWheelSize(container);
      if (nextSize && nextSize !== sizeRef.current) {
        sizeRef.current = nextSize;
        setWheelSize(nextSize);
      }
    };

    const schedule = () => {
      if (frame) {
        return;
      }
      frame = requestAnimationFrame(() => {
        frame = null;
        updateSize();
      });
    };

    updateSize();
    const observer = new ResizeObserver(schedule);
    observer.observe(container);
    window.addEventListener("resize", schedule);
    return () => {
      if (frame) {
        cancelAnimationFrame(frame);
      }
      observer.disconnect();
      window.removeEventListener("resize", schedule);
    };
  }, []);

  useEffect(() => {
    if (!spinning) {
      return;
    }
    if (revealTimeoutRef.current) {
      clearTimeout(revealTimeoutRef.current);
      revealTimeoutRef.current = null;
    }
    setIsRevealed(false);
  }, [spinning]);

  useEffect(() => {
    if (safeSpinIndex != null) {
      return;
    }
    if (spinning || isAnimating) {
      return;
    }
    setIsRevealed(safeSelectedIndex != null);
  }, [safeSpinIndex, safeSelectedIndex, spinning, isAnimating]);

  useEffect(() => {
    if (safeSpinIndex != null || spinning) {
      return;
    }
    setIsAnimating(false);
  }, [safeSpinIndex, spinning]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !wheelSize) {
      return;
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      return;
    }
    const layout = computeLayout(ctx, shortLabels, wheelSize);
    layoutRef.current = layout;
    labelsRef.current = layout.displayLabels;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = layout.size * dpr;
    canvas.height = layout.size * dpr;
    canvas.style.width = `${layout.size}px`;
    canvas.style.height = `${layout.size}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawWheel(ctx, layout, layout.displayLabels, highlightIndex);
    canvas.style.setProperty("--rotation", `${rotationRef.current}deg`);
  }, [shortLabels, wheelSize]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const layout = layoutRef.current;
    if (!canvas || !layout) {
      return;
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      return;
    }
    const dpr = window.devicePixelRatio || 1;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawWheel(ctx, layout, labelsRef.current, highlightIndex);
  }, [highlightIndex]);

  const fallbackResult =
    safeSelectedIndex != null && items[safeSelectedIndex] ? items[safeSelectedIndex] : "";
  const resultValue = resultText || fallbackResult;
  const isSpinning = spinning || isAnimating;
  const revealedValue = isRevealed ? resultValue : "";
  const displayValue = revealedValue || (isSpinning ? "..." : "");
  const displayLabel = displayValue ? resultLabel || "Result" : "";

  const spinningClass = isSpinning ? "spinning" : "";
  const animatingClass = isAnimating ? "animating" : "";

  return (
    <div className={`wheel ${spinningClass} ${animatingClass}`}>
      <div className="wheel-title">{title}</div>
      <div
        className="wheel-body"
        ref={bodyRef}
        style={wheelSize ? { width: `${wheelSize}px` } : undefined}
      >
        <canvas
          className="wheel-disc"
          ref={canvasRef}
        />
        <div className="wheel-center" />
        <div className="wheel-pointer" ref={pointerRef} />
      </div>
      {displayValue ? (
        <div className="wheel-result">
          <div className="wheel-result-label">{displayLabel}</div>
          <div className="wheel-result-value">{displayValue}</div>
        </div>
      ) : null}
    </div>
  );
}

export default Wheel;
